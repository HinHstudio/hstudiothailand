# Aurora files mobile web client module
This module provides the web interface styles for public files in mobile version.

# License
This module is licensed under AGPLv3 license if free version of the product is used or Afterlogic Software License if commercial version of the product was purchased.