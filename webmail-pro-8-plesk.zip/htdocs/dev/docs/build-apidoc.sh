#!/bin/bash

echo "Generate WEB API reference"
apidoc -i ./../../modules/ -o ./../../docs/webapi --config ./../../