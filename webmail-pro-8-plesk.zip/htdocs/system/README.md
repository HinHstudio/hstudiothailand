# Aurora Framework

# Licensing
This package is licensed under AGPLv3 license or Afterlogic Software License if commercial version of the product was purchased.